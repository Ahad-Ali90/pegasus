<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'columns' => [],
    'data' => [],
    'sortable' => false,
    'deleteRoute' => null,  
    'actionView' => null,   
    'sortRoute' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'columns' => [],
    'data' => [],
    'sortable' => false,
    'deleteRoute' => null,  
    'actionView' => null,   
    'sortRoute' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $start = 0;
    if (method_exists($data, 'currentPage') && method_exists($data, 'perPage')) {
        $start = ($data->currentPage() - 1) * $data->perPage();
    }
?>

<div class="overflow-x-auto bg-white shadow-sm sm:rounded-lg">
    <table id="sortableTable" class="min-w-full divide-y divide-gray-200 border" style="width:100%">
        <thead class="bg-gray-50">
            <tr>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">
                        <?php echo e($column['label']); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200 text-center"
            <?php if(collect($columns)->where('sortable', true)->isNotEmpty()): ?>
                id="sortableBody"
            <?php endif; ?>>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr id="row-<?php echo e($row->id); ?>" data-id="<?php echo e($row->id); ?>" class="text-center cursor-move">
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-6 py-2">
                         <?php if($column['field'] === 'actions'): ?>
                                <?php if($actionView): ?>
                                    
                                    <?php echo $__env->make($actionView, [
                                        'id' => $row->id,
                                        'name' => $row,
                                        'deleteRoute' => $deleteRoute ? $deleteRoute($row->id) : '#',
                                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php else: ?>
                                    
                                    <?php echo $__env->make('partials.action-buttons', [
                                        'id' => $row->id,
                                        'name' => $row,
                                        'deleteRoute' => $deleteRoute ? $deleteRoute($row->id) : '#',
                                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php endif; ?>
                            <?php elseif($column['field'] === 'index'): ?>
                                <?php echo e($start + $loop->parent->iteration); ?>

                            <?php else: ?>
                                <?php echo e(data_get($row, $column['field'])); ?>

                            <?php endif; ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e(count($columns)); ?>" class="px-6 py-4 text-center text-gray-500">
                        No records found.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
 <?php if($data->hasPages()): ?>
    <!-- Pagination Links -->
    <div class="mt-4 bg-white p-4 rounded shadow">
        <?php echo e($data->links()); ?>

    </div>
<?php endif; ?>

<?php if(collect($columns)->where('sortable', true)->isNotEmpty()): ?>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    <script>
    const currentPage = <?php echo e($data->currentPage()); ?>;
    const perPage = <?php echo e($data->perPage()); ?>;
    document.addEventListener("DOMContentLoaded", function () {
        new Sortable(document.getElementById('sortableBody'), {
            animation: 150,
            onEnd: function () {
                const order = Array.from(document.querySelectorAll('#sortableBody tr'))
                    .map((row, index) => ({
                        id: row.dataset.id,
                        position: index + 1 + ((currentPage - 1) * perPage)
                    }));
                fetch("<?php echo e(route($sortRoute)); ?>", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    },
                    body: JSON.stringify({ order, page: currentPage, perPage: 10 })
                });
            }
        });
    });
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\Ahad Ali\Desktop\Clone Git\pagasus\resources\views\components\table.blade.php ENDPATH**/ ?>