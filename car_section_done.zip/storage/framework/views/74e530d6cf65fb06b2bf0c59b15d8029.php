<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Projects')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    
                    <div class="mb-4 flex justify-end">
                        <button onclick="openAddModal()"
                            class="px-4 py-2 bg-blue-500 rounded hover:bg-blue-600">
                            + Add Project
                        </button>
                    </div>

                    
                    <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => ['columns' => [
                            ['label' => '#', 'field' => 'index','sortable' => true],
                            ['label' => 'Name', 'field' => 'name'],
                            ['label' => 'Actions', 'field' => 'actions'],
                        ],'data' => $project,'deleteRoute' => fn($id) => route('project.destroy', $id),'actionView' => 'partials.project-action','sortRoute' => 'project.sort']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            ['label' => '#', 'field' => 'index','sortable' => true],
                            ['label' => 'Name', 'field' => 'name'],
                            ['label' => 'Actions', 'field' => 'actions'],
                        ]),'data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($project),'deleteRoute' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(fn($id) => route('project.destroy', $id)),'actionView' => 'partials.project-action','sortRoute' => 'project.sort']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div id="projectModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h3 id="modalTitle" class="text-lg font-bold mb-4">Add Project</h3>
            <form id="projectForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="project_id">

                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Project Name</label>
                    <input type="text" name="name" id="name" class="w-full border-gray-300 rounded mt-1" required>
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="description" id="description" class="w-full border-gray-300 rounded mt-1" rows="3"></textarea>
                </div>

               
                
    <div class="mb-4">
        <label for="keypoints" class="block text-sm font-medium text-gray-700">
            Key Points <small class="text-gray-500">(comma separated)</small>
        </label>
        <textarea name="keypoints" id="keypoints" class="w-full border-gray-300 rounded mt-1" rows="2"></textarea>
    </div>

                
                <div class="mb-4">
                    <label for="techs" class="block text-sm font-medium text-gray-700">
                        Technologies <small class="text-gray-500">(comma separated)</small>
                    </label>
                    <textarea name="techs" id="techs" class="w-full border-gray-300 rounded mt-1" rows="2"></textarea>
                </div>

                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Project Images</label>
                    <input type="file" name="images[]" id="images" multiple class="w-full border-gray-300 rounded mt-1">
                    <small class="text-gray-500">You can upload multiple images</small>
                </div>

                <div class="flex justify-end">
                    <button type="button" onclick="closeModal('projectModal')" class="px-4 py-2 bg-gray-300 rounded danger-btn mr-2">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-blue-500  rounded hover:bg-blue-600" style="margin-left:5px">
                        Save
                    </button>
                </div>
            </form>


        </div>
    </div>

    <script>
    

        function openAddModal() {
            const modal = document.getElementById('projectModal');
            modal.querySelector('form').reset();
            modal.querySelector("#modalTitle").innerText = "Add Project";
            modal.querySelector("#project_id").value = "";
            openModal('projectModal');
        }
function openProjectEditModal(project) {
    const modal = document.getElementById('projectModal');
    modal.querySelector("#modalTitle").innerText = "Edit Project";
    modal.querySelector("#project_id").value = project.id;
    modal.querySelector("#name").value = project.name;

    // For description, usually plain text:
    modal.querySelector("#description").value = project.description ?? '';

    // For keypoints, if it's JSON string, parse and join
    let keypoints = project.keypoints ?? '';
    try {
        const parsed = JSON.parse(keypoints);
        if (Array.isArray(parsed)) {
            keypoints = parsed.filter(Boolean).join(', ');
        }
    } catch {
        // not JSON, leave as is
    }
    
    modal.querySelector("#keypoints").value = keypoints;
let techs = project.techs ?? '';
    try {
        const parsed = JSON.parse(techs);
        if (Array.isArray(parsed)) {
            techs = parsed.filter(Boolean).join(', ');
        }
    } catch {
        // not JSON, leave as is
    }
    modal.querySelector("#techs").value = techs ?? '';
    openModal('projectModal');
}



        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }

      document.querySelector("#projectForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch("<?php echo e(route('project.store')); ?>", {
        method: "POST",
        headers: { "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>" },
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        console.log(data);
        if (data.success) {
            showToast(data.message, "success");
            playSound("success");
            refreshCurrentPage();
            closeModal('projectModal');
        } else {
            showToast("Error saving project", "error");
            playSound("error");
        }
    });
});

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Ahad Ali\Desktop\Clone Git\pagasus\resources\views\projects\index.blade.php ENDPATH**/ ?>