<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'row', 'deleteRoute']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'row', 'deleteRoute']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="flex gap-2 justify-center">
    <button type="button"
        onclick="openEditModal(<?php echo e($id); ?>, '<?php echo e($row->name); ?>')"
        class="px-3 py-1 text-sm text-black bg-green-500 rounded hover:bg-green-600">
        Edit
    </button>
    <form action="<?php echo e($deleteRoute); ?>" 
          method="post" 
          class="inline-block ajax-delete-form"
          data-id="<?php echo e($id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?> 
        <button type="submit" class="px-3 py-1 text-sm bg-red-500 rounded hover:bg-red-600 danger-btn" style="margin-left:5px">
            Delete
        </button>
    </form>
</div>
<?php /**PATH C:\Users\Ahad Ali\Desktop\Clone Git\pagasus\resources\views\partials\skills-action.blade.php ENDPATH**/ ?>