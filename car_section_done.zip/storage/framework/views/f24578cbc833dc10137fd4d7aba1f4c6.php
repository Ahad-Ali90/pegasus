<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Skills')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    
                    <div class="mb-4 flex justify-end">
                        <button onclick="openAddModal()"
                            class="px-4 py-2 bg-blue-500 text-black rounded hover:bg-blue-600">
                        + Add Skill
                        </button>
                    </div>

                    
                        <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => ['columns' => [
                            ['label' => '#', 'field' => 'index', 'sortable' => true],
                            ['label' => 'Name', 'field' => 'name'],
                            ['label' => 'Actions', 'field' => 'actions'],
                        ],'data' => $skills,'deleteRoute' => fn($id) => route('skills.destroy', $id),'actionView' => 'partials.skills-action','sortRoute' => 'skills.sort']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            ['label' => '#', 'field' => 'index', 'sortable' => true],
                            ['label' => 'Name', 'field' => 'name'],
                            ['label' => 'Actions', 'field' => 'actions'],
                        ]),'data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($skills),'deleteRoute' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(fn($id) => route('skills.destroy', $id)),'actionView' => 'partials.skills-action','sortRoute' => 'skills.sort']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Background
<div id="createSkillModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center modal-bg-color">
    <div class="modal-box">
        <h3 id="modalTitle" class="text-lg font-bold mb-4">Add Skill</h3>
        <form id="createSkillForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="skill_id">
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700">Skill Name</label>
                <input type="text" name="name" id="name"
                       class="w-full border-gray-300 rounded mt-1" required>
            </div>
          <div class="flex justify-end">
    <button type="button" onclick="closeModal()" class="px-4 py-2 bg-gray-300 rounded danger-btn" style="margin-right:5px">
        Cancel
    </button>
    <button type="submit" class="px-4 py-2 bg-blue-500 text-black rounded hover:bg-blue-600">
        Save
    </button>
</div>


        </form>
    </div>
</div> -->

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'skillModal','heading' => 'Add Skill','url' => ''.e(route('skills.store')).'','method' => 'POST','submitText' => 'Save','fields' => [
            ['name' => 'id', 'type' => 'hidden'],
            ['name' => 'name', 'label' => 'Skill Name', 'type' => 'text', 'required' => true],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'skillModal','heading' => 'Add Skill','url' => ''.e(route('skills.store')).'','method' => 'POST','submitText' => 'Save','fields' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['name' => 'id', 'type' => 'hidden'],
            ['name' => 'name', 'label' => 'Skill Name', 'type' => 'text', 'required' => true],
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

<!-- <script>
    const modal = document.getElementById('createSkillModal');

  function openEditModal(id, name) {
    document.querySelector("#createSkillModal input[name='id']").value = id;
    document.querySelector("#createSkillModal input[name='name']").value = name;
    document.querySelector("#createSkillModal h3").innerText = "Edit Skill";
    openModal('createSkillModal');
}
function openAddModal() {
    const modal = document.getElementById('createSkillModal');
    const form = modal.querySelector('form');

    // Reset form
    form.reset();

    // Clear hidden id field explicitly
    const hiddenId = form.querySelector("input[name='id']");
    if (hiddenId) hiddenId.value = "";

    // Reset heading
    modal.querySelector("h3").innerText = "Add Skill";

    openModal('createSkillModal');
}

function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
}
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
}


document.querySelector("#createSkillModal form").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const id = formData.get('id');

    let url = id ? "<?php echo e(route('skills.update')); ?>" : "<?php echo e(route('skills.store')); ?>";

    fetch(url, {
        method: "POST",
        headers: { "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>" },
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast(id ? "Skill updated successfully" : "Skill added successfully", "success");
            playSound("success");
            refreshCurrentPage();
            closeModal('createSkillModal');
        } else {
            showToast("Error saving skill", "error");
            playSound("error");
        }
    });
});


</script> -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Ahad Ali\Desktop\Clone Git\pagasus\resources\views\skills\index.blade.php ENDPATH**/ ?>