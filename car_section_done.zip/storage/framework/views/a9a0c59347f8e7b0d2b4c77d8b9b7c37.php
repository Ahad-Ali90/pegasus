<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id' => 'dynamicModal',
    'heading' => 'Modal Heading',
    'url' => '#',
    'method' => 'POST',
    'fields' => [],
    'submitText' => 'Save'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id' => 'dynamicModal',
    'heading' => 'Modal Heading',
    'url' => '#',
    'method' => 'POST',
    'fields' => [],
    'submitText' => 'Save'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div id="<?php echo e($id); ?>" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center modal-bg-color">
    <div class="modal-box w-full max-w-lg">
        <h3 id="<?php echo e($id); ?>Heading" class="text-lg font-bold mb-4"><?php echo e($heading); ?></h3>

        <form id="<?php echo e($id); ?>Form" action="<?php echo e($url); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(in_array(strtoupper($method), ['PUT', 'PATCH', 'DELETE'])): ?>
                <?php echo method_field($method); ?>
            <?php endif; ?>

            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-4">
                    <?php if(($field['type'] ?? 'text') !== 'hidden'): ?>
                        <label for="<?php echo e($field['name']); ?>" class="block text-sm font-medium text-gray-700">
                            <?php echo e($field['label'] ?? ucfirst($field['name'])); ?>

                        </label>
                    <?php endif; ?>

                    <?php if($field['type'] === 'select'): ?>
                        <select name="<?php echo e($field['name']); ?>" id="<?php echo e($field['name']); ?>" class="w-full border-gray-300 rounded mt-1">
                            <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val); ?>"><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    <?php elseif($field['type'] === 'textarea'): ?>
                        <textarea name="<?php echo e($field['name']); ?>" id="<?php echo e($field['name']); ?>" class="w-full border-gray-300 rounded mt-1" rows="4"><?php echo e($field['value'] ?? ''); ?></textarea>

                    <?php elseif($field['type'] === 'radio'): ?>
                        <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="inline-flex items-center mr-4">
                                <input type="radio" name="<?php echo e($field['name']); ?>" value="<?php echo e($val); ?>" class="border-gray-300">
                                <span class="ml-2"><?php echo e($label); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php elseif($field['type'] === 'checkbox'): ?>
                        <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="inline-flex items-center mr-4">
                                <input type="checkbox" name="<?php echo e($field['name']); ?>[]" value="<?php echo e($val); ?>" class="border-gray-300">
                                <span class="ml-2"><?php echo e($label); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                        <input type="<?php echo e($field['type'] ?? 'text'); ?>" 
                               name="<?php echo e($field['name']); ?>" 
                               id="<?php echo e($field['name']); ?>" 
                               value="<?php echo e($field['value'] ?? ''); ?>"
                               class="w-full border-gray-300 rounded mt-1" 
                               <?php echo e($field['required'] ?? false ? 'required' : ''); ?>>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="flex justify-end">
                <button type="button" onclick="closeModal('<?php echo e($id); ?>')" class="px-4 py-2 bg-gray-300 rounded danger-btn mr-2">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-blue-500 text-black rounded hover:bg-blue-600" style="margin-left:5px">
                    <?php echo e($submitText); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openModal(id) {
        document.getElementById(id).classList.remove('hidden');
    }
    function closeModal(id) {
        document.getElementById(id).classList.add('hidden');
    }
</script>

<script>
    const modalId = 'skillModal';
    const modal = document.getElementById(modalId);
    const form = modal.querySelector('form');
    const heading = document.getElementById(modalId + 'Heading');

    function openAddModal() {
        form.reset();
        heading.innerText = heading;
        form.action = "<?php echo e(route('skills.store')); ?>";
        form.method = 'POST';

        // Remove any existing _method input (not needed since same store route)
        let methodInput = form.querySelector('input[name="_method"]');
        if (methodInput) methodInput.remove();

        openModal(modalId);
    }

    function openEditModal(id, name) {
        form.reset();
        heading.innerText = 'Edit Skill';
        form.action = "<?php echo e(route('skills.store')); ?>";  // same store route
        form.method = 'POST';  // always POST

        // Remove any _method input since not needed
        let methodInput = form.querySelector('input[name="_method"]');
        if (methodInput) methodInput.remove();

        // Fill inputs
        form.querySelector('input[name="id"]').value = id;
        form.querySelector('input[name="name"]').value = name;

        openModal(modalId);
    }

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(form);

        fetch(form.action, {
            method: form.method,
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            console.log(JSON.stringify())
            if (data.success) {
                showToast(data.message,'success');
                playSound('success');
                refreshCurrentPage();
                closeModal(modalId);
            } else {
                showToast('Error saving', 'error');
                playSound('error');
            }
        })
        .catch(() => {
            showToast('Error saving', 'error');
            playSound('error');
        });
    });
</script><?php /**PATH C:\Users\Ahad Ali\Desktop\Clone Git\pagasus\resources\views\components\modal.blade.php ENDPATH**/ ?>