<div class="booking-container">
  <div class="right-hero">

    <span class="corner-line corner-top"></span>
    <span class="corner-line corner-right"></span>
    <span class="corner-line corner-bottom"></span>
    <span class="corner-line corner-left"></span>

    <form class="form-box" action="serviceclass.html" method="get">

      <h2>Book Your Ride</h2>

      <div class="form-group">
        <select id="rideType" required onchange="toggleFields()">
          <option value="" disabled selected hidden></option>
          <option value="one-way">One-way</option>
          <option value="hourly">Hourly</option>
        </select>
        <label>Ride Type</label>
      </div>

      <div class="form-group" id="pickup-group">
        <input type="text" placeholder=" " required />
        <label>Pickup Location</label>
      </div>

      <div class="form-group" id="dropoff-group">
        <input type="text" placeholder=" " required />
        <label>Drop-off Location</label>
      </div>

      <div class="form-group" id="duration-group" style="display: none;">
        <select required>
          <option value="" disabled selected hidden></option>
          <option>1 Hour</option>
          <option>2 Hours</option>
          <option>3 Hours</option>
           <option>4 Hours</option>
        <option>5 Hours</option>
        <option>6 Hours</option>
        <option>7 Hours</option>
        <option>8 Hours</option>
        <option>9 Hours</option>
        <option>10 Hours</option>
        <option>11 Hours</option>
        <option>12 Hours</option>
        <option>13 Hours</option>
        <option>14 Hours</option>
        <option>15 Hours</option>
        <option>16 Hours</option>
        <option>17 Hours</option>
        <option>18 Hours</option>
        <option>19 Hours</option>
        <option>20 Hours</option>
        <option>21 Hours</option>
        <option>22 Hours</option>
        <option>23 Hours</option>
        <option>24 Hours</option>
        </select>
        <label>Duration</label>
      </div>

      
      <div class="form-group">
        <input type="datetime-local" placeholder=" " required />
        <label>Date & Time</label>
      </div>

      <button type="submit" class="btn-primary">Search</button>
    </form>
  </div>
</div><?php /**PATH C:\Users\Ahad Ali\Desktop\Clone Git\pagasus\resources\views/layouts/user/heroSection.blade.php ENDPATH**/ ?>